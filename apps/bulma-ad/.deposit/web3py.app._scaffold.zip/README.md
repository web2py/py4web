# _scaffold

to be used as model for other apps
provides example of usage of:

- yatl (Yet Another Template Language)
- DAL (db)
- Session (cookies, redis, memcache, and in db)
- Translator (the T(text) wrapper)
