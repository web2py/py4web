import random
from . common import db, action
from py4web.utils.populate import populate

@action('make')
def make():
    db(db.auth_user.id>1).delete()
    db(db.feed_item.id>0).delete()
    if db(db.auth_user).count()==1:    
        populate(db.auth_user, 10, contents={'is_active':True})
        populate(db.feed_item, 100, contents={'is_active':True, 'parent_id': 0})
        populate(db.item_like, 1000, contents={'is_active':True})
        if 'assigned_score' in db.feed_item.fields:
            db(db.feed_item).update(assigned_score=None, computed_score=None)
        ids = [r.id for r in db(db.auth_user).select() if r.id>1]
        for k in ids[:3]:
            db.friend_request.insert(to_user=1, from_user=k, status='accepted')
            db.friend_request.insert(to_user=k, from_user=1, status='accepted')
        for k in ids[3:6]:
            db.friend_request.insert(to_user=1, from_user=k, status='pending')
        for k in ids[6:9]:
            db.friend_request.insert(to_user=1, from_user=k, status='rejected')
    if 'assigned_score' in db.feed_item.fields:
        if db(db.feed_item).count() == db(db.feed_item.assigned_score==None).count():
            for i in db(db.feed_item).select():
                if random.random()<0.2: i.update_record(assigned_score=-1)
                if random.random()>0.8: i.update_record(assigned_score=+1)
    return 'done'
