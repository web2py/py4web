#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Authors: Luca de Alfaro and Massimo Di Pierro
# License: BSD
# pylint: disable=invalid-name,too-many-branches,too-many-nested-blocks,missing-docstring,too-few-public-methods

import random
import logging

class User:
    def __init__(self, id, score):
        self.id = id
        self.score = float(score or 0.0)
        self.is_ground = score is not None
        self.degree = 0
        self.propagated = self.is_ground

Item = User

class HarmonicFixpoint:
    def compute(self, votes, users, items, steps = 4):
        users = {id: User(id, given_score) for id, given_score in users}
        items = {id: Item(id, given_score) for id, given_score in items}
        # transforms votes into mappings                                                                                                 
        votes = [
            (users.get(user_id), items.get(item_id), float(polarity))
            for user_id, item_id, polarity in votes
            ]
        # convert users and items into lists of Users and Items
        users = list(users.values())
        items = list(items.values())
        # separate non_ground_user from good_users and bad_users
        non_ground_users = [u for u in users if not u.is_ground]
        non_ground_items = [u for u in items if not u.is_ground]
        for k in range(steps):
            for user in non_ground_users:
                user.score = 0.0
                user.degree = 0
            for user, item, polarity in votes:
                if item.propagated:             
                    user.degree += 1
            for user, item, polarity in votes:
                if not user.is_ground and item.propagated:
                    user.propagated = True
                    user.score += polarity * item.score / user.degree                        
            for item in non_ground_items:
                item.score = 0.0
                item.degree = 0
            for user, item, polarity in votes:
                if user.propagated:
                    item.degree += 1
            for user, item, polarity in votes:
                if not item.is_ground and user.propagated:
                    item.propagated = True
                    item.score += polarity * user.score / item.degree
        users = [(u.id, u.score) for u in users]
        items = [(u.id, u.score) for u in items]
        return users, items

def test():
    h = HarmonicFixpoint()
    n = 100000
    users = []
    items = []
    votes = []
    # we make 2n items and 2n users. the first n items are ground truth even are -1 and odd are +1
    for k in range(2*n):
        items.append((k, -1.0+2*(k%2) if k<n else None))
        users.append((k, None))
    # we make 2*n*10 readom votes, 10 for each user 90% of the votes are consistent
    for i in range(2*n):
        user_id = k = random.randint(0, 2*n-1)
        for j in range(10):
            item_id = 2*random.randint(0,n-1) + ((k % 2) if random.random() < 0.9 else (1 - k % 2))
            votes.append((user_id, item_id, 1.0))
    # we run the algorithm
    users, items = h.compute(votes, users, items)
    # we verify that the computed items propgate the expected score based on the behavior of the users
    mean_even = sum(v for i, v in items[n:] if i % 2 == 0)/n*2
    mean_odd = sum(v for i, v in items[n:] if i % 2 == 1)/n*2
    print(mean_even, mean_odd)
    assert mean_even < -0.4
    assert mean_odd > +0.4

if __name__ == '__main__':
    test()
