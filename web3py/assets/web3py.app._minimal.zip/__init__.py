from web3py import action

@action('index')
def index():
    return "Hello World"
