WORK IN PROGRESS

Just know that ``py4web.utils.form.Form`` is a pretty much equivalent to web2py's ``SQLFORM``.

